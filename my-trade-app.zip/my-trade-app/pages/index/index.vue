<template>
  <view class="container">
    <view class="card">
      <text class="label">वॉलेट बैलेंस (Live)</text>
      <text class="balance">₹{{ walletBalance.toFixed(2) }}</text>
      <button class="btn btn-blue" @tap="addDeposit">+ ₹500 डिपॉजिट (5% बोनस)</button>
    </view>

    <view class="card">
      <text class="heading">रिवॉर्ड टास्क</text>
      <view class="task-item">
        <view>
          <text class="task-title">टेलीग्राम जॉइन करें</text>
          <text class="task-desc">₹50 तुरंत बोनस</text>
        </view>
        <button class="btn-sm" @tap="claimTelegram">क्लेम ₹50</button>
      </view>
      <view class="task-item">
        <view>
          <text class="task-title">वॉलेट लिंक करें</text>
          <text class="task-desc">₹20 तुरंत बोनस</text>
        </view>
        <button class="btn-sm" @tap="claimWallet">क्लेम ₹20</button>
      </view>
    </view>

    <view class="card">
      <text class="heading">बाय / सेल ट्रेडिंग (5% कमीशन)</text>
      <input class="input" type="number" v-model="orderAmount" placeholder="अमाउंट (₹) दर्ज करें" />
      <view class="btn-row">
        <button class="btn btn-buy" @tap="placeOrder('BUY')">BUY</button>
        <button class="btn btn-sell" @tap="placeOrder('SELL')">SELL</button>
      </view>
    </view>
  </view>
</template>

<script>
const SUPABASE_URL = 'https://epktoxtdzinybptgdhdu.supabase.co';
const SUPABASE_KEY = 'YOUR_ANON_KEY_HERE'; // यहाँ अपनी Supabase anon public key डालें

export default {
  data() {
    return {
      userId: 'test-user-id',
      walletBalance: 150.00,
      orderAmount: ''
    };
  },
  onShow() {
    this.fetchData();
  },
  methods: {
    fetchData() {
      uni.request({
        url: `${SUPABASE_URL}/rest/v1/profiles?id=eq.${this.userId}&select=*`,
        header: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` },
        success: (res) => {
          if (res.data && res.data[0]) {
            this.walletBalance = Number(res.data[0].wallet_balance || 0);
          }
        }
      });
    },
    placeOrder(type) {
      if (!this.orderAmount || Number(this.orderAmount) <= 0) {
        uni.showToast({ title: 'अमाउंट डालें', icon: 'none' });
        return;
      }
      uni.request({
        url: `${SUPABASE_URL}/rest/v1/orders`,
        method: 'POST',
        header: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json' },
        data: { user_id: this.userId, order_type: type, amount: Number(this.orderAmount), status: 'COMPLETED' },
        success: () => {
          uni.showToast({ title: `${type} पूरा! कमीशन क्रेडिट हुआ`, icon: 'success' });
          this.orderAmount = '';
          setTimeout(() => { this.fetchData(); }, 600);
        }
      });
    },
    claimTelegram() {
      uni.request({
        url: `${SUPABASE_URL}/rest/v1/rpc/claim_telegram_task`,
        method: 'POST',
        header: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` },
        data: { p_user_id: this.userId },
        success: () => {
          uni.showToast({ title: '₹50 बोनस मिला!', icon: 'success' });
          this.fetchData();
        }
      });
    },
    claimWallet() {
      uni.request({
        url: `${SUPABASE_URL}/rest/v1/rpc/claim_wallet_link_task`,
        method: 'POST',
        header: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` },
        data: { p_user_id: this.userId },
        success: () => {
          uni.showToast({ title: '₹20 बोनस मिला!', icon: 'success' });
          this.fetchData();
        }
      });
    },
    addDeposit() {
      uni.request({
        url: `${SUPABASE_URL}/rest/v1/rpc/add_wallet_deposit`,
        method: 'POST',
        header: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` },
        data: { p_user_id: this.userId, p_deposit_amount: 500 },
        success: () => {
          uni.showToast({ title: '₹500 + ₹25 बोनस जमा हुआ', icon: 'success' });
          this.fetchData();
        }
      });
    }
  }
};
</script>

<style>
.container { padding: 16px; background-color: #0f172a; min-height: 100vh; }
.card { background-color: #1e293b; border-radius: 12px; padding: 16px; margin-bottom: 16px; }
.label { font-size: 13px; color: #94a3b8; }
.balance { font-size: 32px; font-weight: bold; color: #38bdf8; margin: 8px 0; display: block; }
.heading { font-size: 16px; font-weight: bold; color: #ffffff; margin-bottom: 10px; display: block; }
.task-item { display: flex; flex-direction: row; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #334155; }
.task-title { font-size: 14px; color: #ffffff; }
.task-desc { font-size: 12px; color: #10b981; }
.input { background-color: #0f172a; border: 1px solid #475569; color: #ffffff; padding: 10px; border-radius: 8px; margin-bottom: 10px; }
.btn-row { display: flex; flex-direction: row; gap: 10px; }
.btn { flex: 1; height: 42px; line-height: 42px; font-size: 14px; font-weight: bold; border-radius: 8px; color: #fff; }
.btn-buy { background-color: #10b981; }
.btn-sell { background-color: #ef4444; }
.btn-blue { background-color: #3b82f6; width: 100%; height: 38px; line-height: 38px; }
.btn-sm { height: 32px; line-height: 32px; font-size: 12px; background-color: #3b82f6; color: #ffffff; }
</style>
