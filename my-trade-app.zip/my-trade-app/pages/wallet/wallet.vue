<template>
  <view class="container">
    <view class="card">
      <text class="label">टोटल कमीशन बैलेंस</text>
      <text class="balance">₹{{ walletBalance.toFixed(2) }}</text>
      <text class="desc">3% Level-1 रेफरल + 1% Level-2 रेफरल कमीशन</text>
    </view>

    <view class="card">
      <text class="heading">हाल के ट्रांजैक्शन्स</text>
      <view v-for="(item, index) in transactions" :key="index" class="tx-item">
        <view>
          <text class="tx-title">{{ item.description || item.type }}\n</text>
          <text class="tx-date">{{ item.created_at.slice(0, 10) }}</text>
        </view>
        <text class="tx-amt">+₹{{ item.amount }}</text>
      </view>
      <text v-if="transactions.length === 0" class="empty-text">कोई ट्रांजैक्शन नहीं मिला</text>
    </view>
  </view>
</template>

<script>
const SUPABASE_URL = 'https://epktoxtdzinybptgdhdu.supabase.co';
const SUPABASE_KEY = 'YOUR_ANON_KEY_HERE';

export default {
  data() {
    return {
      userId: 'test-user-id',
      walletBalance: 0.00,
      transactions: []
    };
  },
  onShow() {
    this.loadData();
  },
  methods: {
    loadData() {
      // बैलेंस
      uni.request({
        url: `${SUPABASE_URL}/rest/v1/profiles?id=eq.${this.userId}&select=wallet_balance`,
        header: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` },
        success: (res) => {
          if (res.data && res.data[0]) this.walletBalance = Number(res.data[0].wallet_balance);
        }
      });
      // ट्रांजैक्शन हिस्ट्री
      uni.request({
        url: `${SUPABASE_URL}/rest/v1/transactions?user_id=eq.${this.userId}&order=created_at.desc&limit=10`,
        header: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` },
        success: (res) => {
          if (res.data) this.transactions = res.data;
        }
      });
    }
  }
};
</script>

<style>
.container { padding: 16px; background-color: #0f172a; min-height: 100vh; }
.card { background-color: #1e293b; border-radius: 12px; padding: 16px; margin-bottom: 16px; }
.label { font-size: 13px; color: #94a3b8; }
.balance { font-size: 32px; font-weight: bold; color: #10b981; margin: 8px 0; display: block; }
.desc { font-size: 12px; color: #94a3b8; }
.heading { font-size: 16px; font-weight: bold; color: #ffffff; margin-bottom: 10px; display: block; }
.tx-item { display: flex; flex-direction: row; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #334155; }
.tx-title { font-size: 14px; color: #ffffff; }
.tx-date { font-size: 11px; color: #64748b; }
.tx-amt { font-size: 15px; font-weight: bold; color: #10b981; }
.empty-text { color: #64748b; font-size: 13px; text-align: center; margin-top: 10px; display: block; }
</style>
